<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

The `memory` module provides a concrete default implementation for the SDK's
`memory` global. For documentation on the `memory` global, see the
[Globals](packages/api-utils/globals.html) reference.
