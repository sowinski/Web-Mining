<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

<!-- contributed by Matteo Ferretti [zer0@mozilla.com] -->

Overview
--------
The `message-manager` module provides a minimalist implementation
of the [Message Manager](https://developer.mozilla.org/en/The_message_manager)
APIs, in a single process environment.

It's mainly used internally for Fennec Birch support.